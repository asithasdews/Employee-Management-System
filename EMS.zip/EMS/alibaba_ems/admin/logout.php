<?php
session_start();

// Destroy all admin session data
session_unset();
session_destroy();

// Redirect to home page (index.php)
header("Location: ../index.php");
exit;
?>
