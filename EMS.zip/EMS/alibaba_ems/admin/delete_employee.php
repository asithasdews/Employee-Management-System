<?php
include('../includes/db.php');
session_start();

// Only allow admin
if(!isset($_SESSION['admin'])){
  header("Location: login.php");
  exit;
}

// Check if ID is passed
if(isset($_GET['id'])){
  $id = intval($_GET['id']); // Convert to integer for safety

  // Delete employee
  $sql = "DELETE FROM employees WHERE id=$id";
  if($conn->query($sql)){
    echo "<script>alert('Employee deleted successfully!'); window.location='dashboard.php';</script>";
  } else {
    echo "<script>alert('Error deleting employee: " . $conn->error . "'); window.location='dashboard.php';</script>";
  }
} else {
  echo "<script>alert('No employee ID provided!'); window.location='dashboard.php';</script>";
}
?>
