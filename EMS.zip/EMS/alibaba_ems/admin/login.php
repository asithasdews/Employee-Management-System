<?php
session_start();
if(isset($_POST['login'])){
  if($_POST['email']=='admin@alibaba.com' && $_POST['password']=='admin123'){
    $_SESSION['admin'] = 'Admin';
    header("Location: dashboard.php");
    exit;
  } else {
    $error = "❌ Wrong credentials!";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Login | Alibaba Pvt Ltd</title>

  <!-- Bootstrap + Google Fonts + Font Awesome -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    * { font-family: 'Poppins', sans-serif; }

    body {
      background: url('../assets/images/admin-bg.jpg') center/cover no-repeat fixed;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background-attachment: fixed;
    }

    .overlay {
      position: fixed;
      top: 0; left: 0;
      width: 100%; height: 100%;
      background: rgba(0, 0, 0, 0.5);
      z-index: 0;
    }

    .login-card {
      position: relative;
      z-index: 1;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(15px);
      border-radius: 20px;
      padding: 45px 40px;
      width: 100%;
      max-width: 400px;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.4);
      animation: fadeIn 1s ease-in-out;
    }

    .login-card h3 {
      font-weight: 600;
      text-align: center;
      margin-bottom: 25px;
      color: #fff;
    }

    .form-control {
      border: none;
      border-radius: 30px;
      padding: 12px 45px 12px 18px;
      background-color: rgba(255,255,255,0.2);
      color: #fff;
    }

    .form-control::placeholder {
      color: rgba(255,255,255,0.8);
    }

    .input-group {
      position: relative;
    }

    .toggle-password {
      position: absolute;
      top: 50%;
      right: 15px;
      transform: translateY(-50%);
      cursor: pointer;
      color: rgba(255,255,255,0.8);
      font-size: 1.1rem;
      transition: color 0.3s;
    }

    .toggle-password:hover {
      color: #ffae00;
    }

    .btn-login {
      width: 100%;
      border-radius: 30px;
      padding: 12px;
      font-weight: 600;
      background: linear-gradient(135deg, #ffae00, #ff7600);
      border: none;
      color: #fff;
      transition: all 0.3s ease;
    }

    .btn-login:hover {
      transform: scale(1.05);
      background: linear-gradient(135deg, #ff7600, #ffae00);
    }

    .error-msg {
      background: rgba(255, 0, 0, 0.3);
      border-left: 4px solid red;
      padding: 8px 12px;
      border-radius: 6px;
      color: #fff;
      margin-bottom: 15px;
      text-align: center;
    }

    .footer-text {
      text-align: center;
      margin-top: 25px;
      color: rgba(255,255,255,0.7);
      font-size: 13px;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>

<body>
  <div class="overlay"></div>

  <div class="login-card">
    <div class="text-center mb-3">
      <img src="../assets/images/logo.png" width="80" alt="Alibaba Logo">
    </div>

    <h3>Admin Login</h3>

    <?php if(isset($error)) echo "<div class='error-msg'>$error</div>"; ?>

    <form method="POST">
      <div class="mb-3">
        <input type="email" name="email" class="form-control" placeholder="Email" required>
      </div>

      <div class="mb-3 input-group">
        <input type="password" id="password" name="password" class="form-control" placeholder="Password" required>
        <i class="fas fa-eye toggle-password" id="togglePassword"></i>
      </div>

      <button name="login" class="btn btn-login mt-2">
        <i class="fas fa-sign-in-alt me-2"></i>Login
      </button>
    </form>

    <p class="footer-text">© 2025 Alibaba Pvt Ltd</p>
  </div>

  <script>
    // 👁️ Show/Hide password
    const togglePassword = document.querySelector('#togglePassword');
    const passwordInput = document.querySelector('#password');

    togglePassword.addEventListener('click', function () {
      const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
      passwordInput.setAttribute('type', type);
      this.classList.toggle('fa-eye-slash');
    });
  </script>
</body>
</html>
