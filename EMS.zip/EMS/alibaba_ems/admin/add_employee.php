<?php
include('../includes/db.php');

if(isset($_POST['save'])){
  $name = $_POST['name'];
  $email = $_POST['email'];
  $position = $_POST['position'];
  $salary = $_POST['salary'];

  // Hash default password
  $password = password_hash('12345', PASSWORD_DEFAULT);

  // Insert into database
  $sql = "INSERT INTO employees (name, email, position, salary, password)
          VALUES ('$name', '$email', '$position', '$salary', '$password')";

  if($conn->query($sql)){
    echo "<script>alert('✅ Employee Added Successfully!'); window.location='dashboard.php';</script>";
  } else {
    echo "<script>alert('❌ Error: " . $conn->error . "');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Employee | Alibaba Pvt Ltd</title>

  <!-- 🌈 Bootstrap 5.3 + Google Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    * { font-family: 'Poppins', sans-serif; }

    body {
      background: linear-gradient(120deg, #000428, #004e92);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
    }

    .card {
      border: none;
      border-radius: 20px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.3);
      overflow: hidden;
      animation: fadeIn 1s ease;
      width: 100%;
      max-width: 500px;
    }

    .card-header {
      background: linear-gradient(135deg, #ffae00, #ff7600);
      color: #fff;
      text-align: center;
      padding: 20px;
      font-weight: 600;
      font-size: 1.4rem;
    }

    .card-body {
      background-color: #fff;
      color: #333;
      padding: 30px;
    }

    .form-control {
      border-radius: 30px;
      padding: 12px 18px;
      border: 1px solid #ccc;
      transition: all 0.3s ease;
    }

    .form-control:focus {
      border-color: #004e92;
      box-shadow: 0 0 8px rgba(0,78,146,0.3);
    }

    .btn-success {
      background: linear-gradient(135deg, #11998e, #38ef7d);
      border: none;
      border-radius: 30px;
      font-weight: 600;
      padding: 12px;
      width: 100%;
      transition: all 0.3s ease;
    }

    .btn-success:hover {
      transform: scale(1.05);
      background: linear-gradient(135deg, #38ef7d, #11998e);
    }

    .back-link {
      display: inline-block;
      margin-top: 15px;
      text-decoration: none;
      color: #004e92;
      font-weight: 500;
      transition: color 0.3s;
    }

    .back-link:hover {
      color: #ff7600;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>

<body>

  <div class="card">
    <div class="card-header">
      <i class="fas fa-user-plus me-2"></i> Add New Employee
    </div>
    <div class="card-body">
      <form method="POST">
        <div class="mb-3">
          <label class="form-label">Full Name</label>
          <input type="text" name="name" class="form-control" placeholder="Enter full name" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Email Address</label>
          <input type="email" name="email" class="form-control" placeholder="Enter email" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Position</label>
          <input type="text" name="position" class="form-control" placeholder="Enter position" required>
        </div>

        <div class="mb-3">
          <label class="form-label">Salary</label>
          <input type="number" step="0.01" name="salary" class="form-control" placeholder="Enter salary" required>
        </div>

        <button name="save" class="btn btn-success mt-2">Save Employee</button>
      </form>

      <a href="dashboard.php" class="back-link d-block text-center mt-3">
        ← Back to Dashboard
      </a>
    </div>
  </div>

  <script src="https://kit.fontawesome.com/a2e0e6adad.js" crossorigin="anonymous"></script>
</body>
</html>
