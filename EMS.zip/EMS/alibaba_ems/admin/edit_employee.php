<?php
session_start();
include('../includes/db.php');

// Only allow admin
if(!isset($_SESSION['admin'])){
  header("Location: login.php");
  exit;
}

// Get employee ID from URL
if(!isset($_GET['id'])){
  echo "<script>alert('No employee ID provided!'); window.location='dashboard.php';</script>";
  exit;
}

$id = intval($_GET['id']);

// Fetch current employee data
$result = $conn->query("SELECT * FROM employees WHERE id=$id");
if($result->num_rows == 0){
  echo "<script>alert('Employee not found!'); window.location='dashboard.php';</script>";
  exit;
}
$emp = $result->fetch_assoc();

// When form is submitted
if(isset($_POST['update'])){
  $name = $_POST['name'];
  $email = $_POST['email'];
  $position = $_POST['position'];
  $salary = $_POST['salary'];

  $sql = "UPDATE employees SET 
          name='$name', 
          email='$email', 
          position='$position', 
          salary='$salary'
          WHERE id=$id";

  if($conn->query($sql)){
    echo "<script>alert('✅ Employee updated successfully!'); window.location='dashboard.php';</script>";
  } else {
    echo "<script>alert('❌ Error updating: " . $conn->error . "');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Employee | Alibaba Pvt Ltd</title>

  <!-- Bootstrap + Icons + Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    * { font-family: 'Poppins', sans-serif; }

    body {
      background: linear-gradient(135deg, #004e92, #000428);
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
    }

    .card {
      background: rgba(255, 255, 255, 0.15);
      backdrop-filter: blur(15px);
      border-radius: 20px;
      padding: 35px;
      width: 100%;
      max-width: 550px;
      color: #fff;
      box-shadow: 0 8px 25px rgba(0, 0, 0, 0.3);
      animation: fadeIn 0.8s ease-in-out;
    }

    .card h3 {
      text-align: center;
      margin-bottom: 25px;
      font-weight: 600;
      color: #ffae00;
    }

    .form-control {
      border: none;
      border-radius: 25px;
      padding: 12px 18px;
      background: rgba(255, 255, 255, 0.2);
      color: #fff;
    }

    .form-control::placeholder {
      color: rgba(255,255,255,0.7);
    }

    .btn-update {
      width: 100%;
      border-radius: 25px;
      padding: 12px;
      font-weight: 600;
      background: linear-gradient(135deg, #38ef7d, #11998e);
      border: none;
      color: white;
      transition: 0.3s;
    }

    .btn-update:hover {
      transform: scale(1.05);
      background: linear-gradient(135deg, #11998e, #38ef7d);
    }

    .btn-back {
      border-radius: 25px;
      padding: 10px 20px;
      font-weight: 500;
      background: linear-gradient(135deg, #ff4b2b, #ff416c);
      color: white;
      border: none;
      text-decoration: none;
      display: inline-block;
      transition: 0.3s;
    }

    .btn-back:hover {
      transform: scale(1.05);
      background: linear-gradient(135deg, #ff416c, #ff4b2b);
      color: white;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

  <div class="card">
    <h3><i class="fas fa-user-edit me-2"></i>Edit Employee</h3>
    <form method="POST">
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($emp['name']) ?>" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($emp['email']) ?>" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Position</label>
        <input type="text" name="position" value="<?= htmlspecialchars($emp['position']) ?>" class="form-control" required>
      </div>

      <div class="mb-4">
        <label class="form-label">Salary</label>
        <input type="number" step="0.01" name="salary" value="<?= htmlspecialchars($emp['salary']) ?>" class="form-control" required>
      </div>

      <button type="submit" name="update" class="btn btn-update mb-3"><i class="fas fa-save me-2"></i>Update Employee</button>
      <div class="text-center">
        <a href="dashboard.php" class="btn-back"><i class="fas fa-arrow-left me-2"></i>Back to Dashboard</a>
      </div>
    </form>
  </div>

</body>
</html>
