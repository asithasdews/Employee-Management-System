<?php
session_start();
include('../includes/db.php');
if(!isset($_SESSION['admin'])) header("Location: login.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Dashboard | Alibaba Pvt Ltd</title>

  <!-- 🌈 Bootstrap 5.3 + Icons + Fonts -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    * { font-family: 'Poppins', sans-serif; }

    body {
      background: linear-gradient(135deg, #c9d6ff, #e2e2e2);
      overflow-x: hidden;
      transition: background 0.3s;
    }

    /* Sidebar */
    .sidebar {
      height: 100vh;
      width: 260px;
      position: fixed;
      top: 0;
      left: 0;
      background: linear-gradient(180deg, #000428, #004e92);
      color: white;
      padding-top: 30px;
      box-shadow: 5px 0 20px rgba(0,0,0,0.2);
      transition: all 0.3s ease;
      z-index: 100;
    }

    .sidebar h3 {
      text-align: center;
      margin-bottom: 30px;
      font-weight: 600;
      color: #ffae00;
    }

    .sidebar a {
      display: block;
      color: white;
      padding: 14px 25px;
      text-decoration: none;
      font-weight: 500;
      border-left: 4px solid transparent;
      transition: all 0.3s ease;
    }

    .sidebar a:hover, .sidebar a.active {
      background: rgba(255,255,255,0.1);
      border-left: 4px solid #ffae00;
      color: #ffae00;
    }

    .logout {
      position: absolute;
      bottom: 20px;
      width: 100%;
      text-align: center;
    }

    .logout a {
      background: linear-gradient(135deg, #ff4b2b, #ff416c);
      border-radius: 25px;
      padding: 8px 18px;
      color: white;
      text-decoration: none;
      transition: 0.3s;
    }

    .logout a:hover {
      transform: scale(1.05);
      opacity: 0.9;
    }

    /* Content */
    .content {
      margin-left: 280px;
      padding: 40px;
      transition: all 0.3s;
      min-height: 100vh;
    }

    .page {
      animation: fadeIn 0.8s ease;
    }

    /* Dashboard cards */
    .card-box {
      background: rgba(255, 255, 255, 0.6);
      backdrop-filter: blur(15px);
      border-radius: 20px;
      padding: 25px;
      text-align: center;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      transition: transform 0.3s, box-shadow 0.3s;
    }

    .card-box:hover {
      transform: translateY(-6px);
      box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    }

    .card-box i {
      font-size: 2.2rem;
      margin-bottom: 10px;
      color: #004e92;
    }

    .card-box h5 {
      font-size: 15px;
      color: #555;
    }

    .card-box h3 {
      font-weight: 700;
      color: #000428;
    }

    /* Table */
    .table-container {
      background: rgba(255, 255, 255, 0.8);
      backdrop-filter: blur(12px);
      border-radius: 20px;
      padding: 25px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
      margin-top: 40px;
      animation: fadeInUp 1s ease;
    }

    table thead {
      background: linear-gradient(90deg, #004e92, #000428);
      color: white;
    }

    table tbody tr:hover {
      background-color: rgba(0, 78, 146, 0.08);
      transition: 0.3s;
    }

    /* Buttons */
    .btn-add {
      border-radius: 30px;
      font-weight: 600;
      padding: 12px 25px;
      background: linear-gradient(135deg, #38ef7d, #11998e);
      border: none;
      color: white;
      transition: all 0.3s;
    }

    .btn-add:hover {
      transform: scale(1.05);
      box-shadow: 0 0 10px rgba(56,239,125,0.6);
    }

    .btn-sm {
      border-radius: 25px;
    }

    .footer {
      text-align: center;
      color: #555;
      margin-top: 40px;
      font-size: 14px;
    }

    /* Toggle for mobile */
    @media (max-width: 768px) {
      .sidebar { left: -260px; }
      .sidebar.active { left: 0; }
      .content { margin-left: 0; }
      .toggle-btn {
        display: block;
        position: fixed;
        top: 15px;
        left: 15px;
        z-index: 999;
        background: #004e92;
        color: white;
        border: none;
        border-radius: 6px;
        padding: 8px 12px;
      }
    }

    .toggle-btn { display: none; }

    /* Animations */
    @keyframes fadeIn { from {opacity: 0; transform: translateY(-10px);} to {opacity: 1; transform: translateY(0);} }
    @keyframes fadeInUp { from {opacity: 0; transform: translateY(20px);} to {opacity: 1; transform: translateY(0);} }
  </style>
</head>

<body>

  <!-- Sidebar -->
  <button class="toggle-btn"><i class="fas fa-bars"></i></button>
  <div class="sidebar" id="sidebar">
    <h3><i class="fas fa-crown me-2"></i>Alibaba Admin</h3>
    <a href="#" class="active" data-page="dashboard"><i class="fas fa-chart-line me-2"></i>Dashboard</a>
    <a href="#" data-page="employees"><i class="fas fa-users me-2"></i>Employees</a>
    <div class="logout">
      <a href="logout.php"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
    </div>
  </div>

  <!-- Main Content -->
  <div class="content" id="content">

    <!-- Dashboard -->
    <div id="dashboard" class="page">
      <?php
      $total = $conn->query("SELECT COUNT(*) AS total FROM employees")->fetch_assoc()['total'];
      $avg_salary = $conn->query("SELECT AVG(salary) AS avg FROM employees")->fetch_assoc()['avg'];
      $latest = $conn->query("SELECT name FROM employees ORDER BY id DESC LIMIT 1")->fetch_assoc()['name'] ?? 'N/A';
      ?>
      <h2 class="fw-bold mb-4 text-primary"><i class="fas fa-chart-line me-2"></i>Dashboard Overview</h2>

      <div class="row g-4">
        <div class="col-md-4">
          <div class="card-box">
            <i class="fas fa-users"></i>
            <h5>Total Employees</h5>
            <h3><?= $total ?></h3>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box">
            <i class="fas fa-dollar-sign"></i>
            <h5>Average Salary</h5>
            <h3><?= $avg_salary ? number_format($avg_salary, 2) : '0.00' ?></h3>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card-box">
            <i class="fas fa-user-check"></i>
            <h5>Last Added Employee</h5>
            <h3><?= $latest ?></h3>
          </div>
        </div>
      </div>

      <div class="text-center mt-5">
        <a href="add_employee.php" class="btn btn-add"><i class="fas fa-user-plus me-2"></i>Add Employee</a>
      </div>
    </div>

    <!-- Employee List -->
    <div id="employees" class="page d-none">
      <h2 class="fw-bold mb-4 text-primary"><i class="fas fa-users me-2"></i>Employee List</h2>
      <div class="table-container">
        <table class="table table-hover align-middle text-center">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Email</th>
              <th>Position</th>
              <th>Salary</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $result = $conn->query("SELECT * FROM employees ORDER BY id DESC");
            if($result->num_rows > 0){
              while($row = $result->fetch_assoc()){
                echo "<tr>
                        <td>{$row['id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['position']}</td>
                        <td>{$row['salary']}</td>
                        <td>
                          <a href='edit_employee.php?id={$row['id']}' class='btn btn-sm btn-primary me-1'><i class='fas fa-edit'></i></a>
                          <a href='delete_employee.php?id={$row['id']}' class='btn btn-sm btn-danger' onclick=\"return confirm('Are you sure you want to delete this employee?');\"><i class='fas fa-trash'></i></a>
                        </td>
                      </tr>";
              }
            } else {
              echo "<tr><td colspan='6' class='text-danger'>No employees found</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <p class="footer">© 2025 Alibaba Pvt Ltd | Designed with ❤️</p>

  <script>
    // Sidebar toggle
    const toggleBtn = document.querySelector('.toggle-btn');
    const sidebar = document.querySelector('#sidebar');
    toggleBtn.addEventListener('click', () => sidebar.classList.toggle('active'));

    // Page navigation
    const links = document.querySelectorAll('.sidebar a[data-page]');
    const pages = document.querySelectorAll('.page');
    links.forEach(link => {
      link.addEventListener('click', e => {
        e.preventDefault();
        const target = link.getAttribute('data-page');
        links.forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        pages.forEach(page => page.classList.add('d-none'));
        document.getElementById(target).classList.remove('d-none');
      });
    });
  </script>
</body>
</html>
