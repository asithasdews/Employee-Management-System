<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome | Alibaba Pvt Ltd</title>

  <!-- 🌈 Libraries -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<!-- 🌟 Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top shadow" style="background: linear-gradient(90deg, #000428, #004e92);">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">
      <img src="assets/images/logo.png" width="40" class="me-2"> Alibaba Pvt Ltd
    </a>
    <div>
      <a href="employee/login.php" class="btn btn-outline-light me-2">Employee Login</a>
      <a href="admin/login.php" class="btn btn-warning text-dark fw-semibold">Admin Login</a>
    </div>
  </div>
</nav>

<!-- 🌄 Hero Section -->
<section class="hero text-center text-light d-flex align-items-center justify-content-center">
  <div class="hero-content" data-aos="zoom-in">
    <h1 class="display-3 fw-bold">Welcome to Alibaba Pvt Ltd</h1>
    <p class="lead">Empowering Businesses with Innovation & Technology</p>
    <a href="employee/login.php" class="btn btn-lg btn-warning mt-3">Get Started</a>
  </div>
</section>

<!-- 💼 Features Section -->
<section class="features text-center py-5">
  <div class="container">
    <h2 class="fw-bold mb-5" data-aos="fade-up">Why Choose Us</h2>
    <div class="row g-4">
      <div class="col-md-4" data-aos="zoom-in">
        <div class="feature-box">
          <i class="fas fa-lightbulb icon"></i>
          <h4>Innovative Solutions</h4>
          <p>We combine creativity and technology to deliver modern business systems.</p>
        </div>
      </div>
      <div class="col-md-4" data-aos="zoom-in" data-aos-delay="200">
        <div class="feature-box">
          <i class="fas fa-users icon"></i>
          <h4>Expert Team</h4>
          <p>Our experienced professionals ensure efficient management and growth.</p>
        </div>
      </div>
      <div class="col-md-4" data-aos="zoom-in" data-aos-delay="400">
        <div class="feature-box">
          <i class="fas fa-shield-alt icon"></i>
          <h4>Secure & Reliable</h4>
          <p>We maintain top-tier security and reliability across all our platforms.</p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- 🦶 Footer -->
<footer class="footer text-center py-4">
  <p class="mb-0">© 2025 Alibaba Pvt Ltd | Designed with ❤️ by the Alibaba Web Team</p>
</footer>

<!-- 🌠 Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script>AOS.init({ duration: 1000, once: true });</script>
</body>
</html>
