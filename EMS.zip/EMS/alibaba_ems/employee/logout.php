<?php
session_start();
session_destroy();

// Redirect to the main home page after logout
header("Location: ../index.php");
exit;
?>
