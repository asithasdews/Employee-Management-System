<?php
session_start();
include('../includes/db.php');
if(!isset($_SESSION['employee'])) header("Location: login.php");

$id = $_SESSION['employee'];
$user = $conn->query("SELECT * FROM employees WHERE id=$id")->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Dashboard | Alibaba Pvt Ltd</title>

  <!-- Bootstrap + Fonts + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">

  <style>
    * { font-family: 'Poppins', sans-serif; }

    body {
      background: url('../assets/images/employee-bg.jpg') center/cover no-repeat fixed;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
      margin: 0;
      overflow-x: hidden;
    }

    .dashboard-card {
      background: rgba(255, 255, 255, 0.12);
      backdrop-filter: blur(15px);
      border-radius: 20px;
      padding: 40px 35px;
      max-width: 450px;
      width: 100%;
      text-align: center;
      color: #000;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.3);
      animation: fadeIn 1s ease-in-out;
    }

    .dashboard-card h2 {
      font-weight: 700;
      color: #00c3ff;
      margin-bottom: 10px;
    }

    /* 🖤 Make info text black */
    .dashboard-card p {
      font-size: 15px;
      margin-bottom: 10px;
      color: #000 !important;
      font-weight: 500;
    }

    .profile-icon {
      width: 100px;
      height: 100px;
      background: linear-gradient(135deg, #00c3ff, #004e92);
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 40px;
      margin: 0 auto 20px;
      color: #fff;
      box-shadow: 0 0 15px rgba(0, 195, 255, 0.6);
    }

    .btn-custom {
      border-radius: 30px;
      padding: 10px 20px;
      font-weight: 600;
      color: #fff;
      border: none;
      transition: all 0.3s ease;
      width: 100%;
      margin-bottom: 12px;
    }

    .btn-warning {
      background: linear-gradient(135deg, #ffae00, #ff7600);
    }

    .btn-danger {
      background: linear-gradient(135deg, #ff416c, #ff4b2b);
    }

    .btn-custom:hover {
      transform: scale(1.05);
      opacity: 0.9;
    }

    .footer-text {
      text-align: center;
      margin-top: 20px;
      color: rgba(0, 0, 0, 0.6);
      font-size: 13px;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>

<body>
  <div class="dashboard-card">
    <div class="profile-icon">
      <i class="fas fa-user-circle"></i>
    </div>
    <h2>Welcome, <?= htmlspecialchars($user['name']) ?> 👋</h2>

    <p><i class="fas fa-envelope me-2 text-primary"></i><?= htmlspecialchars($user['email']) ?></p>
    <p><i class="fas fa-briefcase me-2 text-primary"></i><?= htmlspecialchars($user['position']) ?></p>
    <p><i class="fas fa-dollar-sign me-2 text-success"></i><strong><?= number_format($user['salary'], 2) ?></strong></p>

    <hr style="border-color: rgba(0, 0, 0, 0.2);">

    <a href="change_password.php" class="btn btn-custom btn-warning">
      <i class="fas fa-key me-2"></i>Change Password
    </a>

    <a href="logout.php" class="btn btn-custom btn-danger">
      <i class="fas fa-sign-out-alt me-2"></i>Logout
    </a>

    <p class="footer-text mt-3">© 2025 Alibaba Pvt Ltd | Employee Dashboard</p>
  </div>
</body>
</html>
