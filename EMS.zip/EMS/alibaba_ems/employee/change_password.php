<?php
session_start();
include('../includes/db.php');
if(!isset($_SESSION['employee'])) header("Location: login.php");

$id = $_SESSION['employee'];
if(isset($_POST['change'])){
  $newpass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
  $conn->query("UPDATE employees SET password='$newpass' WHERE id=$id");
  echo "<script>alert('Password updated!');</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Change Password</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-5">
  <div class="container col-md-4">
    <h3>Change Password</h3>
    <form method="POST">
      <input type="password" name="new_password" class="form-control mb-3" placeholder="New Password" required>
      <button name="change" class="btn btn-success w-100">Change Password</button>
    </form>
  </div>
</body>
</html>
