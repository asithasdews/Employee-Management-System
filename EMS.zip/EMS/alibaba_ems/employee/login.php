<?php
include('../includes/db.php');
session_start();

if(isset($_POST['login'])){
  $email = trim($_POST['email']);
  $password = trim($_POST['password']);

  $sql = "SELECT * FROM employees WHERE email='$email'";
  $result = $conn->query($sql);

  if($result && $result->num_rows > 0){
    $user = $result->fetch_assoc();

    if(password_verify($password, $user['password'])){
      $_SESSION['employee'] = $user['id'];
      header("Location: dashboard.php");
      exit;
    } else {
      $error = "❌ Incorrect password!";
    }
  } else {
    $error = "⚠️ No employee found with that email!";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Employee Login | Alibaba Pvt Ltd</title>

  <!-- Bootstrap 5.3 + Fonts + Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

  <style>
    * { font-family: 'Poppins', sans-serif; }

    body {
      background: url('../assets/images/employee-bg.jpg') center/cover no-repeat fixed;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      color: #fff;
    }

    .login-card {
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(15px);
      border-radius: 20px;
      padding: 40px 35px;
      width: 100%;
      max-width: 400px;
      color: #fff;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.4);
      animation: fadeIn 1s ease-in-out;
    }

    .login-card h3 {
      text-align: center;
      margin-bottom: 25px;
      font-weight: 600;
      color: #00c3ff;
    }

    .form-control {
      border: none;
      border-radius: 30px;
      padding: 12px 18px;
      background: rgba(255,255,255,0.2);
      color: #fff;
    }

    .form-control::placeholder {
      color: rgba(255,255,255,0.8);
    }

    .btn-login {
      width: 100%;
      border-radius: 30px;
      padding: 12px;
      font-weight: 600;
      background: linear-gradient(135deg, #00c3ff, #004e92);
      border: none;
      color: #fff;
      transition: all 0.3s ease;
    }

    .btn-login:hover {
      transform: scale(1.05);
      background: linear-gradient(135deg, #004e92, #00c3ff);
    }

    .error-msg {
      background: rgba(255, 0, 0, 0.3);
      border-left: 4px solid red;
      padding: 8px 12px;
      border-radius: 6px;
      color: #fff;
      margin-bottom: 15px;
      text-align: center;
    }

    .password-toggle {
      position: absolute;
      top: 50%;
      right: 15px;
      transform: translateY(-50%);
      color: #fff;
      cursor: pointer;
    }

    .footer-text {
      text-align: center;
      margin-top: 20px;
      color: rgba(255,255,255,0.7);
      font-size: 13px;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(-20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>

<body>
  <div class="login-card">
    <div class="text-center mb-3">
      <img src="../assets/images/logo.png" width="80" alt="Alibaba Logo">
    </div>

    <h3>Employee Login</h3>

    <?php if(isset($error)) echo "<div class='error-msg'>$error</div>"; ?>

    <form method="POST">
      <div class="mb-3 position-relative">
        <input type="email" name="email" class="form-control" placeholder="Email" required>
      </div>

      <div class="mb-3 position-relative">
        <input type="password" name="password" id="password" class="form-control" placeholder="Password" required>
        <i class="fa-solid fa-eye password-toggle" id="togglePassword"></i>
      </div>

      <button name="login" class="btn btn-login mt-2">Login</button>
    </form>

    <p class="footer-text">© 2025 Alibaba Pvt Ltd</p>
  </div>

  <script>
    // Password show/hide toggle
    const togglePassword = document.querySelector("#togglePassword");
    const password = document.querySelector("#password");
    togglePassword.addEventListener("click", function () {
      const type = password.getAttribute("type") === "password" ? "text" : "password";
      password.setAttribute("type", type);
      this.classList.toggle("fa-eye-slash");
    });
  </script>
</body>
</html>
